# Pipeline Detection Robot with 3D Scanning

This project implements a low-cost, IoT-enabled pipeline inspection robot using an ESP32 microcontroller, ESP32-CAM, Blynk IoT platform, and a custom web interface.

## 🚀 Features
- Real-time video streaming inside pipelines
- Remote robot control via Blynk app and browser
- Speed control and directional movement
- Wi-Fi-based telemetry and status feedback

## 🧰 Hardware Used
- ESP32
- ESP32-CAM
- L298N Motor Driver
- DC Motors
- Battery Pack
- FTDI USB-to-Serial (for CAM)
- Robot Chassis

## 📁 Folders
- `esp32_control/`: Arduino code to control the robot
- `web_interface/`: HTML control interface
- `images/`: Add block diagram, circuit, output photos here

## 📲 How to Use
1. Upload `pipeline_robot_control.ino` to ESP32.
2. Upload ESP32-CAM code (not included).
3. Host `index.html` locally or integrate in ESP32 filesystem.
4. Use Blynk app or browser to control the robot.

---

© 2025 K. Sindhu Gowri | Department of ECE
